JET Simple Access Layer (SAL) Client 
====================================

Simple Access Layer (SAL) is a Python API for accessing JET data. SAL is designed to wrap all of JETs current data systems and make them appear as one, single unified system. It serves as a new, modern platform on which we can rapidly make new improvements - if you have any suggestions please feel free to file an issue or contact the Software Engineering Group.
  
The goal of the new system is to simplify and unify. It is designed to be easy to learn and easy to use. If you want to give it a go, you can right now! Log into a cluster machine, load the python/3 module, start ipython and type the following: 

```python
# try this in ipython (requires the python/3 module to be loaded) 
from jet.data import sal

# obtain list of magnetics signals
sal.list('/pulse/87737/ppf/signal/jetppf/magn')

# quickly plot plasma current signal
sal.show('/pulse/87737/ppf/signal/jetppf/magn/ipla')

# read plasma current signal
s = sal.get('/pulse/87737/ppf/signal/jetppf/magn/ipla')
```

As the new API is built on web technologies, it is possible for you to use it in any place python 3.5+ is installed - your desktop, cluster machines etc... - as long as you have access to the central data server. Should you have a need to do this, please feel free to contact the Software Engineering group and we'll show you how.

For more information please see the  [JET SAL quickstart guide](https://data.jet.uk/guides/sal). 