#!/usr/bin/env bash

# this script must be run from the JET sal client python project root

mkdir zip_release
cd zip_release

git clone git+ssh://git@git.ccfe.ac.uk/simple-access-layer/jet-sal-dataclasses.git --branch v1.0.0 jet-dataclasses
git clone git+ssh://git@git.ccfe.ac.uk/simple-access-layer/jet-sal-client-python.git --branch v1.3.1 jet-client
cp ../dev/install.txt install.txt

rm sal/.git -rf
rm jet-dataclasses/.git -rf
rm jet-client/.git -rf

zip -r release.zip jet-dataclasses jet-client install.txt
mv release.zip ..
cd ..

rm zip_release -rf
