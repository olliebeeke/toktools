from sal.core.exception import SALException
from sal.core.object import Branch
from sal.client import SALClient
from sal.dataclass.signal import *
from jet.data.dataclass import *

__all__ = ['authenticate', 'list', 'get', 'put', 'delete', 'copy', 'show', 'client', 'SALClient', 'SALException', 'JET_DATA_HOST']

JET_DATA_HOST = 'https://sal.jet.uk'

# module level functions
client = SALClient(JET_DATA_HOST)
authenticate = client.authenticate
list = client.list
get = client.get
put = client.put
copy = client.copy
delete = client.delete


def show(path):
    """
    Displays node data for the specific path.

    This function is intended to help users quickly explore the data available
    in the data tree. It will identify the type of data on the specified path
    and display that data using an appropriate visualisation. This may be a
    graph, audio playback or simply printing appropriate data to the command
    line.

    :param path: A valid node path.
    :raises InvalidPath: If the supplied path is invalid.
    :raises NodeNotFound: If the path does not point ot a node.
    :raises PermissionDenied: If the group does not have permission to access the node.
    """

    HANDLER = {
        Scalar: _show_scalar,
        String: _show_string,
        Array: _show_array,
        Dictionary: _show_dictionary,
        Signal: _show_signal,
        PulseComment: _show_pulse_comment
    }

    # obtain object or branch report
    d = get(path)
    if isinstance(d, Branch):
        d = list(path)

    # display results   
    try:
        HANDLER[d.__class__](d, path)
    except KeyError:
        print(d)


def _show_scalar(d, path):
    """
    Prints the scalar contents to the screen.
    """

    print('description: {}'.format(d.description))
    print('value: {}'.format(d.value))


def _show_string(d, path):
    """
    Prints the scalar contents to the screen.
    """

    print('description: {}'.format(d.description))
    print('value: {}'.format(d.value))


def _show_array(d, path):
    """
    Prints the scalar contents to the screen.
    """

    print('description: {}'.format(d.description))
    print('data: {}'.format(d.data))


def _show_dictionary(d, path):
    """
    Prints the scalar contents to the screen.
    """

    print('description: {}'.format(d.description))
    print('items:')
    for k, v in d.items():
        print('  {}: {}'.format(k, v))


def _show_signal(d, path):
    """
    Displays a signal object as a plot.
    """

    # only import on demand
    try:
        import matplotlib.pyplot as plt
        from .colour import viridis_cm
    except ImportError:
        raise ImportError('The required matplotlib package is not available, please install it for signal show support.')

    n = len(d.dimensions)
    if n == 1:

        fig = plt.figure()
        plt.plot(d.dimensions[0].data, d.data)
        plt.xlabel(d.dimensions[0].units)
        plt.ylabel(d.units)
        plt.title(path)
        plt.grid(axis='both', which="major", color=(0.8, 0.8, 0.8), linestyle="-")
        plt.grid(axis='both', which="minor", color=(0.9, 0.9, 0.9), linestyle="-")
        plt.minorticks_on()
        fig.axes[0].set_axisbelow(True)

    elif n == 2:

        fig = plt.figure()
        plt.pcolormesh(
            d.dimensions[0].data,
            d.dimensions[1].data,
            d.data.transpose(),
            cmap=viridis_cm,
            shading="gouraud"
        )
        plt.autoscale(tight=True)
        cbar = plt.colorbar()
        cbar.set_label(d.units)
        plt.xlabel(d.dimensions[0].units)
        plt.ylabel(d.dimensions[1].units)
        plt.grid(axis='both', which="major", linestyle="-", alpha=.5)
        plt.minorticks_on()

    else:
        raise ValueError('Unable to plot signals with dimensions > 2')

    plt.show()


def _show_pulse_comment(d, path):
    """
    Prints a pulse comment to the screen.
    """

    print('description: {}\n'.format(d.description))
    print('author: {}\n'.format(d.author))
    print('summary:\n{}\n'.format(_indent_string(d.comment_summary)))
    print('pre-pulse comment:\n{}\n'.format(_indent_string(d.prepulse)))
    print('post-pulse comment:\n{}\n'.format(_indent_string(d.postpulse)))

    if d.physics_quality:
        print('physics quality: {}\n'.format(d.physics_quality))

    if d.causes:
        print('causes:')
        for group, causes in d.causes.items():
            print('  * {}'.format(group))
            for cause in causes:
                print('      - {}'.format(cause))


def _indent_string(s, n=2):
    """
    Indents the string by the specified number of spaces.
    :param s: String.
    :return: Indented string.
    """

    indent = ' ' * n
    return '{}{}'.format(indent, s.replace('\n', '\n{}'.format(indent)))

