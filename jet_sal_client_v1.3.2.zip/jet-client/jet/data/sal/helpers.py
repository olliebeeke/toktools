from .client import get as _get


def jpf_to_sal(node):
    """
    Converts a node name from native JPF format to SAL format.

    SAL nodes have a limited character set so escape special characters.
    """
    replacements = {
        '>': '_out_',
        '<': '_in_',
        ':': '_sq_',
        '$': '_do_',
        '&': '_et_',
        ' ': '_sp_'
    }

    node = node.strip().lower()
    for r in replacements:
        node = node.replace(r, replacements[r])
    return node


def sal_to_jpf(node):
    """
    Converts a node name from SAL format to native JPF format.

    SAL nodes have a limited character set so escape special characters.
    """
    replacements = {
        '_out_': '>',
        '_in_': '<',
        '_sq_': ':',
        '_do_': '$',
        '_et_': '&',
        '_sp_': ' '
    }

    node = node.strip().lower()
    for r in replacements:
        node = node.replace(r, replacements[r])
    return node.upper()
