from setuptools import setup, find_packages

setup(
    name="jet.data.sal",
    version="1.3.2",
    packages=find_packages(),
    namespace_packages=['jet', 'jet.data'],
)
