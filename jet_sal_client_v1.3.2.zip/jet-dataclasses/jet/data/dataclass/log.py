from re import match
import numpy as np
from sal.core.object import DataObject, DataSummary, dataclass


class PulseCommentSummary(DataSummary):
    """
    The summary object for a Pulse Comment log entry.

    See the PulseComment class for more information.
    """

    CLASS = 'log_pulse_comment'
    GROUP = 'jet'
    VERSION = 1

    def __init__(self, description=None):
        """
        :param description: A string describing the log (default='A pulse comment log record.').
        """

        description = description or 'A pulse comment log record.'
        super().__init__(description)

    def to_dict(self):
        """
        Return a dictionary representation of the object.

        :return: A (LogSummary) data object dictionary.
        """

        return self._new_dict()

    @classmethod
    def from_dict(cls, d):
        """
        Instances a new object from a dictionary representation.

        :param d: Dictionary containing a serialised LogSummary.
        :return: An instance of LogSummary.
        """

        if not cls.is_compatible(d):
            raise ValueError('The dictionary does not contain a serialised PulseCommentSummary class')
        return cls(description=d['description'])


@dataclass.register
class PulseComment(DataObject):
    """
    A JET pulse comment log entry.

    Represents a single pulse comment log entry within JET logging. These log
    entries can be recorded by multiple different users, such as the session
    leader and engineer in charge.
    """

    CLASS = 'log_pulse_comment'
    GROUP = 'jet'
    VERSION = 1
    SUMMARY_CLASS = PulseCommentSummary

    def __init__(self, comment_summary, author, prepulse, postpulse,
                 physics_quality=None, causes=None, description=None):
        """
        :param comment_summary: The log entry's summary data.
        :param author: The name of the user that the log was created by.
        :param prepulse: Text about the pulse entered before it happened.
        :param postpulse: Text about the pulse entered after it happened.
        :param physics_quality: String representing whether a pulse produced
               results as desired or not.
        :param causes: Dictionary of system-level causes, with values being a
               list of more specific causes of issues during the pulse.
        :param description: A string describing the log (default='A pulse
               comment log record.').
        """

        # validate/sanitise
        comment_summary = str(comment_summary)
        author = str(author)
        prepulse = str(prepulse)
        postpulse = str(postpulse)

        if physics_quality is not None:
            physics_quality = str(physics_quality)

        if causes is not None:
            causes = dict(causes)
            self._validate_causes(causes)

        # populate
        self.comment_summary = comment_summary
        self.author = author
        self.prepulse = prepulse
        self.postpulse = postpulse
        self.physics_quality = physics_quality
        self.causes = causes
        super().__init__(description)

    def summary(self):
        """
        Returns a summary instance of the PulseComment object.

        :return: A PulseCommentSummary object.
        """
        return self.SUMMARY_CLASS(self.comment_summary)

    def to_dict(self):
        """
        Returns a dictionary representation of the PulseComment instance.

        :return: A (PulseComment) data object dictionary.
        """

        v = super()._new_dict()

        v.update({
            'comment_summary': self.comment_summary,
            'prepulse': self.prepulse,
            'postpulse': self.postpulse,
            'author': self.author,
            'description': self.description
        })

        if self.causes:
            causes = self._causes_list_to_numpy(self.causes)
            v['causes'] = causes

        if self.physics_quality:
            v['physics_quality'] = self.physics_quality

        return v

    @classmethod
    def from_dict(cls, d):
        """
        Return a PulseComment instance from the given dictionary object.

        :param d: A dictionary representing the PulseComment object.
        :return: A PulseComment instance based on the provided dictionary.
        """
        if not cls.is_compatible(d):
            raise ValueError('The dictionary does not contain a serialised PulseComment object')

        try:
            physics_quality = d['physics_quality']
        except KeyError:
            physics_quality = None

        try:
            causes = d['causes']
            causes = cls._causes_numpy_to_list(causes)
        except KeyError:
            causes = None

        c = cls(
            comment_summary=d['comment_summary'],
            author=d['author'],
            prepulse=d['prepulse'],
            postpulse=d['postpulse'],
            physics_quality=physics_quality,
            causes=causes,
            description=d['description']
        )

        return c

    @classmethod
    def _validate_causes(cls, causes):
        """
        Checks data in causes dictionary.

        :param causes: Causes dictionary.
        """

        for key, value in causes.items():

            # check key type
            if not isinstance(key, str):
                raise TypeError('Cause list keys must be python string objects.')

            # check key contents
            if match(r"^[a-z0-9.\-_]+$", key) is None:
                raise ValueError('Cause list keys must consist of only the characters [a-z], [0-9], \'.\', \'-\', and \'_\'.')

            # check value is a list of strings
            if not isinstance(value, list):
                raise TypeError('Cause lists must be python list objects.')

            for item in causes[key]:
                if not isinstance(item, str):
                    raise TypeError('Cause strings must be python string objects.')

    @classmethod
    def _causes_list_to_numpy(cls, causes):
        """
        Converts lists of strings to numpy array of strings in causes dictionary.

        :param causes: Causes dictionary.
        :return: Causes dictionary.
        """

        return {key: np.array(value, dtype=str) for key, value in causes.items()}

    @classmethod
    def _causes_numpy_to_list(cls, causes):
        """
        Converts lists of strings to numpy array of strings in causes dictionary.

        :param causes: Causes dictionary.
        :return: Causes dictionary.
        """

        return {key: value.tolist() for key, value in causes.items()}

