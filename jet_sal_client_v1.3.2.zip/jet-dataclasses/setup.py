from setuptools import setup, find_packages

setup(
    name='jet.data.dataclasses',
    version='1.0.1',
    packages=find_packages(),
    namespace_packages=['jet', 'jet.data'],
)
